# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form2_2.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_From2(object):
    def setupUi(self, form2):
        form2.setObjectName("form2")
        form2.resize(1023, 600)
        self.widget = QtWidgets.QWidget(form2)
        self.widget.setGeometry(QtCore.QRect(0, 0, 1024, 600))
        self.widget.setStyleSheet("border-image: url(./UI/背景文字框.png);")
        self.widget.setObjectName("widget")
        self.pushButton = QtWidgets.QPushButton(self.widget)
        self.pushButton.setGeometry(QtCore.QRect(301, 511, 219, 40))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy)
        self.pushButton.setMinimumSize(QtCore.QSize(219, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("QPushButton { \n"
"    color: rgb(23,45,141);\n"
"    border-image: url(./UI/标题栏按钮2.png);\n"
"border:3px;\n"
"color:yellow; \n"
"border-radius:150px;\n"
"background-color:yellow; \n"
"}\n"
"QPushButton:hover {\n"
"color:black;\n"
"border-radius:20px;\n"
"background-color:rgba(0,255,0,200); \n"
"}\n"
"QPushButton:pressed { \n"
"color: rgb(238, 238, 236);\n"
"border-width:3;\n"
"border-color:orange;\n"
"border-style:solid;\n"
"background-color:(178,34,34); \n"
"}")
        self.pushButton.setObjectName("pushButton")
        self.calendarWidget = QtWidgets.QCalendarWidget(self.widget)
        self.calendarWidget.setEnabled(True)
        self.calendarWidget.setGeometry(QtCore.QRect(210, 80, 600, 400))
        self.calendarWidget.setFont(font)
        self.calendarWidget.setMouseTracking(False)
        self.calendarWidget.setTabletTracking(False)
        self.calendarWidget.setStyleSheet("border-image: url(./UI/透明背景.png);\n"
                                          "background-color:rgb(46, 52, 54); \n"
                                          "color:rgb(128,128,128); \n"
                                          "alternate-background-color:rgb(46, 52, 54);")
        self.calendarWidget.setInputMethodHints(QtCore.Qt.ImhNone)
        self.calendarWidget.setMinimumDate(QtCore.QDate(2022, 1, 1))
        self.calendarWidget.setMaximumDate(QtCore.QDate(2099, 12, 31))
        self.calendarWidget.setFirstDayOfWeek(QtCore.Qt.Monday)
        self.calendarWidget.setGridVisible(True)
        self.calendarWidget.setHorizontalHeaderFormat(QtWidgets.QCalendarWidget.ShortDayNames)
        self.calendarWidget.setVerticalHeaderFormat(QtWidgets.QCalendarWidget.NoVerticalHeader)
        self.calendarWidget.setNavigationBarVisible(True)
        self.calendarWidget.setDateEditEnabled(True)



        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setGeometry(QtCore.QRect(526, 511, 219, 40))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pushButton_2.sizePolicy().hasHeightForWidth())
        self.pushButton_2.setSizePolicy(sizePolicy)
        self.pushButton_2.setMinimumSize(QtCore.QSize(219, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("QPushButton { \n"
"    color: rgb(23,45,141);\n"
"    border-image: url(./UI/标题栏按钮2.png);\n"
"border:3px;\n"
"color:yellow; \n"
"border-radius:150px;\n"
"background-color:yellow; \n"
"}\n"
"QPushButton:hover {\n"
"color:black;\n"
"border-radius:20px;\n"
"background-color:rgba(0,255,0,200); \n"
"}\n"
"QPushButton:pressed { \n"
"color: rgb(238, 238, 236);\n"
"border-width:3;\n"
"border-color:orange;\n"
"border-style:solid;\n"
"background-color:(178,34,34); \n"
"}")
        self.pushButton_2.setObjectName("pushButton_2")

        self.showlabel = QtWidgets.QLabel(self.widget)
        self.showlabel.setGeometry(QtCore.QRect(240, 123, 548, 312))
        self.showlabel.setStyleSheet("border-image: url(./UI/透明背景.png);\n"
                                "QScrollBar{color:rgb(46, 52, 54)}")
        self.showlabel.setAlignment(QtCore.Qt.AlignCenter)
        self.showlabel.setObjectName("showlabel")

        # self.listView = QtWidgets.QListView(self.widget)
        # self.listView.setGeometry(QtCore.QRect(240, 123, 548, 312))
        # self.listView.setStyleSheet("border-image: url(./UI/透明背景.png);\n"
        #                         "QScrollBar{color:rgb(46, 52, 54)}")
        #
        #
        # self.listView.setAutoScrollMargin(17)
        # self.listView.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        # self.listView.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        # self.listView.setTextElideMode(QtCore.Qt.ElideNone)
        # self.listView.setModelColumn(0)
        # self.listView.setObjectName("listView")

        self.retranslateUi(form2)
        QtCore.QMetaObject.connectSlotsByName(form2)

    def retranslateUi(self, form2):
        _translate = QtCore.QCoreApplication.translate
        form2.setWindowTitle(_translate("form2", "Dialog"))
        self.pushButton.setText(_translate("form2", "查询"))
        self.pushButton_2.setText(_translate("form2", "返回"))

