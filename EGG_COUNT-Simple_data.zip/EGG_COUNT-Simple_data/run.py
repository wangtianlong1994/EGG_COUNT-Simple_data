import sys
#import wiringpi
import datetime
from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow

from Homepage_gui import *
from Send_email_gui import *
from Historical_query1_gui import *

import cv2
import torch

import numpy as np
from utils import scale_coords,Annotator,colors
from data_loader import non_max_suppression,letterbox
from tflite_models import DetectMultiBackend
from send_email import *
from thread_function import *


# 主界面
class MyMainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(MyMainWindow, self).__init__()
        self.timer_video = QtCore.QTimer()  # 创建定时器
        self.setupUi(self)
        self.cap = cv2.VideoCapture(0)
        self.count_egg = 0
        self.day_count_egg = 0
        self.conf_thres = 0.65
        self.iou_thres = 0.45
        self.agnostic = False
        self.state = True
        self.weights = "./last-fp16.tflite"
        self.device = torch.device("cpu")
        self.data = "./egg_class.yaml"
        self.models = DetectMultiBackend(weights=self.weights, device=self.device, dnn=False, data=self.data)
        self.imgsz = (320, 320)
        self.new_date = str(time.strftime("%Y-%m-%d", time.localtime()))
        self.induction_times = 0
        self.start_time = str(time.strftime("%H:%M:%S", time.localtime()))
        self.mythread = MyThread() # 实例化自己建立的任务线程类

        self.init_slots()

    def init_slots(self):
        self.timer_video.start(30)
        self.timer_video.timeout.connect(self.show_video_frame)
        self.mythread.signals.connect(self.start_check) #设置任务线程发射信号触发的函数
        self.mythread.start()
        self.pushButton_3.clicked.connect(self.exit_def) # 关闭

    def start_check(self,i):
        self.state = i

    # 定义视频帧显示操作
    def show_video_frame(self):
        flag, img0 = self.cap.read()

        if not self.state:
            print("zhixing")
            t1 = datetime.datetime.now().microsecond
            t3 = time.mktime(datetime.datetime.now().timetuple())
            stride, names, pt = self.models.stride, self.models.names, self.models.pt
            half = False
            bs = 1
            # Padded resize
            im = letterbox(img0, self.imgsz, stride=stride, auto=False)[0]
            # Convert
            im = im.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
            im = np.ascontiguousarray(im)
            self.models.warmup(imgsz=(1 if pt else bs, 3, *self.imgsz), half=half)  # warmup
            # for path, im, im0, s in self.dataset:
            im = torch.from_numpy(im).to(self.device)
            im = im.half() if half else im.float()  # uint8 to fp16/32
            im /= 255  # 0 - 255 to 0.0 - 1.0
            print(im.shape)
            if len(im.shape) == 3:
                im = im[None]  # expand for batch dim
            # Inference
            pred = self.models(im)
            # NMS
            pred = non_max_suppression(pred, conf_thres=self.conf_thres, iou_thres=self.iou_thres, agnostic=self.agnostic)
            # Process predictions
            for i, det in enumerate(pred):  # per image
                annotator = Annotator(img0, line_width=3, example=str(names))
                if len(det):
                    # Rescale boxes from img_size to im0 size
                    det[:, :4] = scale_coords(im.shape[2:], det[:, :4], img0.shape).round()
                    # Print results
                    for c in det[:, -1].unique():
                        n = (det[:, -1] == c).sum()  # detections per class
                    # Write results
                    # 得到单张图片置信框总数
                    box_count = len(det)
                    for *xyxy, conf, cls in reversed(det):
                        c = int(cls)  # integer class
                        label = f'{names[c]} {conf:.2f}'
                        # 置信框变量循环一次减少一次
                        box_count -= 1
                        # 判2断置信框中心点是否在图片设置范围内，如果不在范围内，直接忽略，同时判断是否是最后一个置信框，如果是，结束并图片显示剩余所有框数量
                        if 150 >= int(xyxy[0] + xyxy[2]) / 2 or int(xyxy[0] + xyxy[2]) / 2 >= 550:
                            if box_count == 0:
                                annotator.box_label(xyxy, label, self.count_egg, txt_ny=1)
                                break
                            continue
                        # 中心点在图片设置范围内，鸡蛋总数+1
                        self.count_egg += 1
                        # 判断置信框是否是最后一个，如果不是将框绘制到图片并继续循环，如果是最后一个，将最后一个框绘制完毕后同时将鸡蛋总数绘制图片并结束循环
                        if box_count == 0:
                            annotator.box_label(xyxy, label, self.count_egg, color=colors(c, True))
                            break
                        annotator.box_label(xyxy, label, color=colors(c, True))
                # Stream results
                im0 = annotator.result()
                # 图片缩放到界面视频大小
                show = cv2.resize(im0, (self.vido_size_w,self.vido_size_h))
                self.result = cv2.cvtColor(show, cv2.COLOR_BGR2RGB)
                showImage = QtGui.QImage(self.result.data, self.result.shape[1], self.result.shape[0],
                                         QtGui.QImage.Format_RGB888)
                self.Camear1.setPixmap(QtGui.QPixmap.fromImage(showImage))

                # 显示当前图片鸡蛋数量到界面
                self.label_1_1.setText(str(self.count_egg))
                # 当前图片鸡蛋数量与当日鸡蛋数量相加并存入数据库和刷新界面当日鸡蛋数量显示
                sql = Database_Control()
                self.day_count_egg += self.count_egg
                sql.exit_insert_daily_egg_count_sql(self.new_date,self.day_count_egg)
                self.label_2_2.setText(str(self.day_count_egg))
                self.count_egg = 0
            t2 = datetime.datetime.now().microsecond
            t4 = time.mktime(datetime.datetime.now().timetuple())
            strTime = 'funtion time use:%dms' % ((t4 - t3) * 1000 + (t2 - t1) / 1000)
            print(strTime)

            # 判断当前时间是否是打开时间，如果不是，重新创建当前时间数据库币并刷新所有数据
            current_date = str(time.strftime("%H:%M:%S", time.localtime()))
            if self.new_date != current_date:
                self.new_date = current_date
                sql = Database_Control()
                day_egg = sql.create_daily_egg_count_sql(self.new_date)
                self.day_count_egg = day_egg
                self.label_2_2.text(self.day_count_egg)
            self.state = True

    def exit_def(self):
        sql = Database_Control()
        # exit_time = str(time.strftime("%H:%M:%S", time.localtime()))
        # exit_date = str(time.strftime("%Y-%m-%d", time.localtime()))
        sql.exit_insert_daily_egg_count_sql(self.new_date, self.day_count_egg)
        self.close()
# 邮件发送
class ChildWindow(QDialog, Ui_Form):
    def __init__(self):
        super(ChildWindow, self).__init__()
        self.setupUi(self)
        self.init_slots()
        self.counts = 60
        self.new_date = str(time.strftime("%Y-%m-%d", time.localtime()))

    def init_slots(self):
        self.pushButton_2.clicked.connect(self.to_email)
        self.pushButton_3.clicked.connect(self.close)
        self.time = QtCore.QTimer(self)
        self.time.setInterval(1000)
        self.time.timeout.connect(self.button_set_time)
    
    def to_email(self):
        if self.pushButton_2.isEnabled():
            self.time.start()
            self.pushButton_2.setEnabled(False)
            if send_to_email(self.new_date):
                print("ok")
            else:
                print("no")
            
            
            
  
    def button_set_time(self):
        if self.counts > 0:

            self.counts -= 1
        else:
            self.time.stop()
            self.pushButton_2.setEnabled(True)
            self.counts = 60

            

        
# 历史查看
class Child1Window(QDialog, Ui_From2):
    def __init__(self):
        super(Child1Window, self).__init__()
        self.setupUi(self)
        self.init_slots()
        self.showlabel.hide()
        
    def init_slots(self):
        self.pushButton.clicked.connect(self.select_all_egg)
        self.pushButton_2.clicked.connect(self.closeYN)

    def select_all_egg(self):
        select_date = self.calendarWidget.selectedDate().toString("yyyy-MM-dd")
        sql = Database_Control()
        all_date_egg = sql.select_daily_egg_count_sql(select_date)
        self.calendarWidget.hide()
        self.showlabel.show()
        self.pushButton_2.setText("重新查询/返回")
        self.showlabel.setFont(QtGui.QFont("Roman times", 40, QtGui.QFont.Bold))
        if all_date_egg:
            res1 = f"{select_date}\n鸡蛋总数量:\n{all_date_egg}\n"
            self.showlabel.setText(res1)
        else:
            res1 = f"{select_date}\n鸡蛋总数量:\n0\n"
            self.showlabel.setText(res1)
                    
                
    def closeYN(self):
        if self.calendarWidget.isHidden():
            self.calendarWidget.show()
            self.showlabel.hide()
            self.pushButton_2.setText("返回")
        else:
            self.close()
if __name__ == '__main__':
    

    app = QApplication(sys.argv)
    main = MyMainWindow()
    child = ChildWindow()
    child1 = Child1Window()

    btn = main.pushButton  # 
    btn.clicked.connect(child.show)

    btn1 = main.pushButton_2  # 设置
    btn1.clicked.connect(child1.show)

    # 判断数据库中是否存在当日数据
    sql = Database_Control()
    today_count = sql.select_daily_egg_count_sql(main.new_date)
    if today_count:
        print(today_count)
        main.day_count_egg = today_count
        main.label_2_2.setText(today_count)
    else:
        main.label_2_2.setText(str(main.day_count_egg))
    # 当日数量显示到屏幕

    
    # main.showFullScreen()
    main.show()
    sys.exit(app.exec_())

