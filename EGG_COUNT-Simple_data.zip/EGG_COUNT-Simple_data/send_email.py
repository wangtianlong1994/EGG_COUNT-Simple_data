import smtplib
from email.mime.text import MIMEText
from email.header import Header
from set_sql import *


# 邮件发送功能模块
def send_to_email(new_date):
    # 第三方 SMTP 服务
    mail_host="smtp.163.com"  #设置服务器
    mail_user="15517517053@163.com"    #用户名
    mail_pass="OLJVKUEMDWKBYMKL"   #口令 

    sender = '15517517053@163.com'
    receivers = ['358618595@qq.com']  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱
    egg_count = Database_Control()
    egg_counts = egg_count.select_daily_egg_count_sql(new_date)
    
    message = MIMEText(f'{new_date}当日鸡蛋数量为：{egg_counts}', 'plain', 'utf-8')
    message['From'] = Header(sender, 'utf-8')
    message['To'] =  Header(receivers[0], 'utf-8')
     
    subject = '鸡蛋当日数量'
    message['Subject'] = Header(subject, 'utf-8')
     
     
    try:
        smtpObj = smtplib.SMTP() 
        smtpObj.connect(mail_host, 25)    # 25 为 SMTP 端口号
        smtpObj.login(mail_user,mail_pass)  
        smtpObj.sendmail(sender, receivers, message.as_string())
        return 1
    except smtplib.SMTPException as e:
        print(e)
        return 0
