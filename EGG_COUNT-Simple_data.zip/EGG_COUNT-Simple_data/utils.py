import re
import glob
import torch
from pathlib import Path
import cv2
import numpy as np
import pandas as pd

# zi dong sheng cheng bao cun tui li hou shu jv
def increment_path(path, exist_ok=False, sep='', mkdir=False):
    # Increment file or directory path, i.e. runs/exp --> runs/exp{sep}2, runs/exp{sep}3, ... etc.
    path = Path(path)  # os-agnostic
    if path.exists() and not exist_ok:
        path, suffix = (path.with_suffix(''), path.suffix) if path.is_file() else (path, '')
        dirs = glob.glob(f"{path}{sep}*")  # similar paths
        matches = [re.search(rf"%s{sep}(\d+)" % path.stem, d) for d in dirs]
        i = [int(m.groups()[0]) for m in matches if m]  # indices
        n = max(i) + 1 if i else 2  # increment number
        path = Path(f"{path}{sep}{n}{suffix}")  # increment path
    if mkdir:
        path.mkdir(parents=True, exist_ok=True)  # make directory
    return path

# qingchu wuxiao zifuchuan
def clean_str(s):
    # Cleans a string by replacing special characters with underscore _
    return re.sub(pattern="[|@#!¡·$€%&()=?¿^*;:,¨´><+]", repl="_", string=s)

def export_formats():
    # YOLOv5 export formats
    x = [['PyTorch', '-', '.pt'],
         ['TorchScript', 'torchscript', '.torchscript'],
         ['ONNX', 'onnx', '.onnx'],
         ['OpenVINO', 'openvino', '_openvino_model'],
         ['TensorRT', 'engine', '.engine'],
         ['CoreML', 'coreml', '.mlmodel'],
         ['TensorFlow SavedModel', 'saved_model', '_saved_model'],
         ['TensorFlow GraphDef', 'pb', '.pb'],
         ['TensorFlow Lite', 'tflite', '.tflite'],
         ['TensorFlow Edge TPU', 'edgetpu', '_edgetpu.tflite'],
         ['TensorFlow.js', 'tfjs', '_web_model']]
    return pd.DataFrame(x, columns=['Format', 'Argument', 'Suffix'])

def check_suffix(file='yolov5s.pt', suffix=('.pt',), msg=''):
    # Check file(s) for acceptable suffix
    if file and suffix:
        if isinstance(suffix, str):
            suffix = [suffix]
        for f in file if isinstance(file, (list, tuple)) else [file]:
            s = Path(f).suffix.lower()  # file suffix
            if len(s):
                assert s in suffix, f"{msg}{f} acceptable suffix is {suffix}"


# yucekuang huazai shujvshang
class Annotator:
    # YOLOv5 Annotator for train/val mosaics and jpgs and detect/hub inference annotations
    def __init__(self, im, line_width=None, font_size=None, font='Arial.ttf', pil=False, example='abc'):
        self.im = im
        self.lw = line_width or max(round(sum(im.shape) / 2 * 0.003), 2)  # line width

    def box_label(self, box, label='',count_egg_all=None, color=(128, 128, 128), txt_color=(255, 255, 255),txt_ny=None):
        if not txt_ny:
            # 得到置信框两点相对坐标
            p1, p2 = (int(box[0]), int(box[1])), (int(box[2]), int(box[3]))
            # 得到置信框中心点坐标并绘制
            self.im = cv2.circle(self.im, (int((box[0] + box[2]) / 2), int((box[1] + box[3]) / 2)), 1, color, thickness=-1)
            cv2.rectangle(self.im, p1, p2, color, thickness=self.lw, lineType=cv2.LINE_AA)
            # 得到图片设置范围两边线并绘制
            p1ce, p2ce = (150, 0), (150, 1280)
            p3ce, p4ce = (550, 0), (550, 1280)
            self.im = cv2.rectangle(self.im, p1ce, p2ce, color, thickness=1, lineType=cv2.LINE_AA)
            self.im = cv2.rectangle(self.im, p3ce, p4ce, color, thickness=1, lineType=cv2.LINE_AA)
        #     if count_egg_all:
        #         count_text = f"egg={count_egg_all}"
        #         cv2.putText(self.im, count_text, (100, 100), 0, self.lw, (255, 255, 255),
        #                     thickness=max(self.lw - 1, 1), lineType=cv2.LINE_AA)
        # # 如果当前是最后一个置信框并且不在范围内，直接绘制鸡蛋总数
        # else:
        #     count_text = f"egg={count_egg_all}"
        #     cv2.putText(self.im, count_text, (100, 100), 0, self.lw, (255, 255, 255),
        #                 thickness=max(self.lw - 1, 1), lineType=cv2.LINE_AA)
        # if label:
        #     tf = max(self.lw - 1, 1)  # font thickness
        #     w, h = cv2.getTextSize(label, 0, fontScale=self.lw / 3, thickness=tf)[0]  # text width, height
        #     outside = p1[1] - h - 3 >= 0  # label fits outside box
        #     p2 = p1[0] + w, p1[1] - h - 3 if outside else p1[1] + h + 3
        #     cv2.rectangle(self.im, p1, p2, color, -1, cv2.LINE_AA)  # filled
        #     cv2.putText(self.im, label, (p1[0], p1[1] - 2 if outside else p1[1] + h + 2), 0, self.lw / 3, txt_color,
        #                 thickness=tf, lineType=cv2.LINE_AA)

    def result(self):
        # Return annotated image as array
        return np.asarray(self.im)

# yanse
class Colors:
    # Ultralytics color palette https://ultralytics.com/
    def __init__(self):
        # hex = matplotlib.colors.TABLEAU_COLORS.values()
        hex = ('FF3838', 'FF9D97', 'FF701F', 'FFB21D', 'CFD231', '48F90A', '92CC17', '3DDB86', '1A9334', '00D4BB',
               '2C99A8', '00C2FF', '344593', '6473FF', '0018EC', '8438FF', '520085', 'CB38FF', 'FF95C8', 'FF37C7')
        self.palette = [self.hex2rgb('#' + c) for c in hex]
        self.n = len(self.palette)

    def __call__(self, i, bgr=False):
        c = self.palette[int(i) % self.n]
        return (c[2], c[1], c[0]) if bgr else c

    @staticmethod
    def hex2rgb(h):  # rgb order (PIL)
        return tuple(int(h[1 + i:1 + i + 2], 16) for i in (0, 2, 4))


colors = Colors()  # create instance for 'from utils.plots import colors'





def scale_coords(img1_shape, coords, img0_shape, ratio_pad=None):
    # Rescale coords (xyxy) from img1_shape to img0_shape
    if ratio_pad is None:  # calculate from img0_shape
        gain = min(img1_shape[0] / img0_shape[0], img1_shape[1] / img0_shape[1])  # gain  = old / new
        pad = (img1_shape[1] - img0_shape[1] * gain) / 2, (img1_shape[0] - img0_shape[0] * gain) / 2  # wh padding
    else:
        gain = ratio_pad[0][0]
        pad = ratio_pad[1]

    coords[:, [0, 2]] -= pad[0]  # x padding
    coords[:, [1, 3]] -= pad[1]  # y padding
    coords[:, :4] /= gain
    clip_coords(coords, img0_shape)
    return coords


def clip_coords(boxes, shape):
    # Clip bounding xyxy bounding boxes to image shape (height, width)
    if isinstance(boxes, torch.Tensor):  # faster individually
        boxes[:, 0].clamp_(0, shape[1])  # x1
        boxes[:, 1].clamp_(0, shape[0])  # y1
        boxes[:, 2].clamp_(0, shape[1])  # x2
        boxes[:, 3].clamp_(0, shape[0])  # y2
    else:  # np.array (faster grouped)
        boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, shape[1])  # x1, x2
        boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, shape[0])  # y1, y2
