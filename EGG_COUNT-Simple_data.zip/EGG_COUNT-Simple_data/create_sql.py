import sqlite3

# 创建初始数据库，每次装软件，只需要加载一次！！！

class Create_Sqlite(object):
    def __init__(self):
        self.conn = sqlite3.connect("egg.db")
        self.curs = self.conn.cursor()

    def create_sql(self):
        self.curs.execute(
            "CREATE TABLE daily_egg_count (Date char(8) not null, Count char(8) not null DEFAULT 0, UNIQUE (Date) ON CONFLICT REPLACE)")
        # self.curs.execute("CREATE TABLE egg_count (Start_Date char(8) not null, Start_time char(6), Exit_date char(6) DEFAULT 0, Exit_time char(6) DEFAULT 0, Count text DEFAULT 0);")
        self.conn.commit()
        self.conn.close()


c = Create_Sqlite()
c.create_sql()