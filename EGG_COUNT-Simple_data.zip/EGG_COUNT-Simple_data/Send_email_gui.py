# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form1.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

# 邮件发送界面

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1024, 600)
        self.widget = QtWidgets.QWidget(Form)
        self.widget.setGeometry(QtCore.QRect(0, 0, 1024, 600))
        self.widget.setStyleSheet("border-image: url(./UI/背景.png);")
        self.widget.setObjectName("widget")
        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setGeometry(QtCore.QRect(460, 320, 127, 110))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pushButton_2.sizePolicy().hasHeightForWidth())
        self.pushButton_2.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("color: rgb(0, 0, 0);\n"
"border-image: url(./UI/邮件手动发送按钮2.png);")
        self.pushButton_2.setText("")
        self.pushButton_2.setIconSize(QtCore.QSize(16, 16))
        self.pushButton_2.setStyleSheet("QPushButton { \n"
"    color: rgb(23,45,141);\n"
"    border-image: url(./UI/邮件手动发送按钮2.png);\n"
"border:3px;\n"
"color:yellow; \n"
"border-radius:150px;\n"
"background-color:yellow; \n"
"}\n"
"QPushButton:hover {\n"
"color:black;\n"
"border-radius:20px;\n"
"background-color:rgba(0,255,0,200); \n"
"}\n"
"QPushButton:pressed { \n"
"border-image: url(./UI/邮件手动发送按下.png);\n"
"color: rgb(238, 238, 236);\n"
"border-width:3;\n"
"border-color:orange;\n"
"border-style:solid;\n"
"background-color:(178,34,34); \n"
"}")
        self.pushButton_2.setObjectName("pushButton_2")
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setGeometry(QtCore.QRect(260, 190, 162, 40))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setMinimumSize(QtCore.QSize(162, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setStyleSheet("border-image: url(./UI/文字背景.png);\n"
"color: rgb(238, 238, 236);")
        self.label.setObjectName("label")
        self.lineEdit = QtWidgets.QLineEdit(self.widget)
        self.lineEdit.setGeometry(QtCore.QRect(440, 190, 330, 40))
        self.lineEdit.setReadOnly(True)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.lineEdit.sizePolicy().hasHeightForWidth())
        self.lineEdit.setSizePolicy(sizePolicy)
        self.lineEdit.setMinimumSize(QtCore.QSize(330, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.lineEdit.setFont(font)
        self.lineEdit.setStyleSheet("border-image: url(./UI/文本框3.png);")
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton_3 = QtWidgets.QPushButton(self.widget)
        self.pushButton_3.setGeometry(QtCore.QRect(300, 510, 440, 40))
        self.pushButton_3.setMinimumSize(QtCore.QSize(417, 40))

        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.pushButton_3.setStyleSheet("QPushButton { \n"
"    color: rgb(23,45,141);\n"
"    border-image: url(./UI/标题栏按钮2.png);\n"
"border:3px;\n"
"color:yellow; \n"
"border-radius:150px;\n"
"background-color:yellow; \n"
"}\n"
"QPushButton:hover {\n"
"color:black;\n"
"border-radius:20px;\n"
"background-color:rgba(0,255,0,200); \n"
"}\n"
"QPushButton:pressed { \n"
"color: rgb(238, 238, 236);\n"
"border-width:3;\n"
"border-color:orange;\n"
"border-style:solid;\n"
"background-color:(178,34,34); \n"
"}")
        self.pushButton_3.setObjectName("pushButton_3")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label.setText(_translate("Form", "  邮件地址:"))
        self.pushButton_3.setText(_translate("Form", "返回"))
        self.lineEdit.setText(_translate("Form", "123@qq.com"))
