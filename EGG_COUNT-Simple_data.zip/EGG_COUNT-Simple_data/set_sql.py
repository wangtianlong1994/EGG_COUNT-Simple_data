import sqlite3


class Database_Control(object):
    def __init__(self):
        self.conn = sqlite3.connect("egg.db")
        self.curs = self.conn.cursor()

    def create_sql(self):
        self.curs.execute("CREATE TABLE daily_egg_count (Date char(8) not null, Count char(8) not null DEFAULT 0, UNIQUE (Date) ON CONFLICT REPLACE)")
        # self.curs.execute("CREATE TABLE egg_count (Start_Date char(8) not null, Start_time char(6), Exit_date char(6) DEFAULT 0, Exit_time char(6) DEFAULT 0, Count text DEFAULT 0);")
        self.conn.commit()
        self.conn.close()
        
    # def start_insert_egg_count_sql(self, new_date, start_time):
    # #self.curs.execute("UPDATE egg_count SET Count = (%s) where Date=(%s)" % (count_egg, new_date))
    #     self.curs.execute('INSERT INTO egg_count (Start_Date,Start_time) VALUES (?,?)',(new_date,start_time))
    #     self.conn.commit()
    #     self.conn.close()
    #

    # 创建当日数据，并返回初始鸡蛋数量
    def create_daily_egg_count_sql(self, new_date):
        self.curs.execute('INSERT INTO daily_egg_count (Date, Count) VALUES (?,?)', (new_date, 0))
        self.conn.commit()
        self.conn.close()


    # 根据当前打开软件日期 查询数据库中是否存在当日数据，存在则返回当日数量，不存在则创建当日数据
    def select_daily_egg_count_sql(self, new_date):
        select_today_count = f'SELECT Count from daily_egg_count where Date="{new_date}"'
        today_count = self.curs.execute(select_today_count).fetchone()
        if today_count:
            self.conn.commit()
            self.conn.close()
            return today_count[0]
        else:
            self.create_daily_egg_count_sql(new_date)

    
    def exit_insert_daily_egg_count_sql(self,new_date, day_count_egg):
        #self.curs.execute("UPDATE egg_count SET Count = (%s) where Date=(%s)" % (count_egg, new_date))
        self.curs.execute('INSERT INTO daily_egg_count (Date,Count) VALUES (?,?)',(new_date, day_count_egg,))
        self.conn.commit()
        self.conn.close()
    
    # def select_all_daily_egg_count_sql(self, new_date):
    #     select_today_count = f'SELECT Count from daily_egg_count where Date="{new_date}"'
    #     a = self.curs.execute(select_today_count)
    #     egg_count = a.fetchone()
    #     self.conn.commit()
    #     self.conn.close()
    #     return egg_count
    
    # def select_all_egg_count_sql(self, new_date):
    #     select_today_count = f'SELECT * from egg_count where Start_Date="{new_date}"'
    #     a = self.curs.execute(select_today_count)
    #     egg_count = a.fetchall()
    #     print(egg_count)
    #     self.conn.commit()
    #     self.conn.close()
    #     return egg_count





# c = Database_Control()
# # c.create_sql()
