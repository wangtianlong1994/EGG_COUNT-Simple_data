# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow2.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

import cv2
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        self.vido_size_w = 590
        self.vido_size_h = 390
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1024, 600)
        MainWindow.setMaximumSize(QtCore.QSize(16777215, 16777215))
        MainWindow.setStyleSheet("")
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setStyleSheet("border-image: url(./UI/背景.png);")
        self.centralWidget.setObjectName("centralWidget")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralWidget)
        self.pushButton_2.setGeometry(QtCore.QRect(190, 530, 219, 40))
        self.pushButton_2.setMinimumSize(QtCore.QSize(219, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("QPushButton { \n"
"    color: rgb(23,45,141);\n"
"    border-image: url(./UI/标题栏按钮2.png);\n"
"border:3px;\n"
"color:yellow; \n"
"border-radius:150px;\n"
"background-color:yellow; \n"
"}\n"
"QPushButton:hover {\n"
"color:black;\n"
"border-radius:20px;\n"
"background-color:rgba(0,255,0,200); \n"
"}\n"
"QPushButton:pressed { \n"
"color: rgb(238, 238, 236);\n"
"border-width:3;\n"
"border-color:orange;\n"
"border-style:solid;\n"
"background-color:(178,34,34); \n"
"}")
        self.pushButton_2.setObjectName("pushButton_2")
        self.label_2 = QtWidgets.QLabel(self.centralWidget)
        self.label_2.setGeometry(QtCore.QRect(523, 491, 150, 30))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)
        self.label_2.setMinimumSize(QtCore.QSize(150, 30))
        self.label_2.setMaximumSize(QtCore.QSize(150, 25))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(False)
        font.setWeight(50)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("border-image: url(./UI/文字背景.png);\n"
"color: rgb(252, 233, 79);")
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.label_1_1 = QtWidgets.QLabel(self.centralWidget)
        self.label_1_1.setGeometry(QtCore.QRect(267, 491, 250, 30))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_1_1.sizePolicy().hasHeightForWidth())
        self.label_1_1.setSizePolicy(sizePolicy)
        self.label_1_1.setMinimumSize(QtCore.QSize(250, 30))
        self.label_1_1.setMaximumSize(QtCore.QSize(250, 25))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(False)
        font.setWeight(50)
        self.label_1_1.setFont(font)
        self.label_1_1.setStyleSheet("border-image: url(./UI/文本框3.png);\n"
"color: rgb(252, 233, 79);")
        self.label_1_1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_1_1.setObjectName("label_1_1")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralWidget)
        self.pushButton_3.setGeometry(QtCore.QRect(630, 530, 219, 40))
        self.pushButton_3.setMinimumSize(QtCore.QSize(219, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setStyleSheet("QPushButton { \n"
"    color: rgb(23,45,141);\n"
"    border-image: url(./UI/标题栏按钮2.png);\n"
"border:3px;\n"
"color:yellow; \n"
"border-radius:150px;\n"
"background-color:yellow; \n"
"}\n"
"QPushButton:hover {\n"
"color:black;\n"
"border-radius:20px;\n"
"background-color:rgba(0,255,0,200); \n"
"}\n"
"QPushButton:pressed { \n"
"color: rgb(238, 238, 236);\n"
"border-width:3;\n"
"border-color:orange;\n"
"border-style:solid;\n"
"background-color:(178,34,34); \n"
"}")
        self.pushButton_3.setObjectName("pushButton_3")
        self.label_1 = QtWidgets.QLabel(self.centralWidget)
        self.label_1.setGeometry(QtCore.QRect(111, 491, 150, 30))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_1.sizePolicy().hasHeightForWidth())
        self.label_1.setSizePolicy(sizePolicy)
        self.label_1.setMinimumSize(QtCore.QSize(150, 30))
        self.label_1.setMaximumSize(QtCore.QSize(150, 25))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(False)
        font.setWeight(50)
        self.label_1.setFont(font)
        self.label_1.setStyleSheet("border-image: url(./UI/文字背景.png);\n"
"color: rgb(252, 233, 79);")
        self.label_1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_1.setObjectName("label_1")
        self.label_2_2 = QtWidgets.QLabel(self.centralWidget)
        self.label_2_2.setGeometry(QtCore.QRect(679, 491, 250, 30))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_2_2.sizePolicy().hasHeightForWidth())
        self.label_2_2.setSizePolicy(sizePolicy)
        self.label_2_2.setMinimumSize(QtCore.QSize(250, 30))
        self.label_2_2.setMaximumSize(QtCore.QSize(250, 25))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(False)
        font.setWeight(50)
        self.label_2_2.setFont(font)
        self.label_2_2.setStyleSheet("border-image: url(./UI/文本框3.png);\n"
"color: rgb(252, 233, 79);")
        self.label_2_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2_2.setObjectName("label_2_2")
        self.Camear_frame = QtWidgets.QLabel(self.centralWidget)
        self.Camear_frame.setGeometry(QtCore.QRect(202, 75, 610, 410))
        self.Camear_frame.setStyleSheet("border-image: url(./UI/显示边框.jpeg);")
        self.Camear_frame.setText("")
        self.Camear_frame.setObjectName("Camear_frame")
        self.Camear1 = QtWidgets.QLabel(self.centralWidget)
        self.Camear1.setGeometry(QtCore.QRect(210, 85, self.vido_size_w, self.vido_size_h))
        self.Camear1.setStyleSheet("border-image: url(./UI/文字背景1.png);")
        self.Camear1.setText("")
        self.Camear1.setObjectName("Camear1")
        self.pushButton = QtWidgets.QPushButton(self.centralWidget)
        self.pushButton.setGeometry(QtCore.QRect(410, 530, 219, 40))
        self.pushButton.setMinimumSize(QtCore.QSize(219, 40))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("QPushButton { \n"
"    color: rgb(23,45,141);\n"
"    border-image: url(./UI/标题栏按钮2.png);\n"
"border:3px;\n"
"color:yellow; \n"
"border-radius:150px;\n"
"background-color:yellow; \n"
"}\n"
"QPushButton:hover {\n"
"color:black;\n"
"border-radius:20px;\n"
"background-color:rgba(0,255,0,200); \n"
"}\n"
"QPushButton:pressed { \n"
"color: rgb(238, 238, 236);\n"
"border-width:3;\n"
"border-color:orange;\n"
"border-style:solid;\n"
"background-color:(178,34,34); \n"
"}")
        self.pushButton.setIconSize(QtCore.QSize(16, 30))
        self.pushButton.setObjectName("pushButton")
        MainWindow.setCentralWidget(self.centralWidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton_2.setText(_translate("MainWindow", "每日数量"))
        self.label_2.setText(_translate("MainWindow", "今日累计："))
        self.label_1_1.setText(_translate("MainWindow", "0"))
        self.pushButton_3.setText(_translate("MainWindow", "退出软件"))
        self.label_1.setText(_translate("MainWindow", "当前数量："))
        self.label_2_2.setText(_translate("MainWindow", "0"))
        self.pushButton.setText(_translate("MainWindow", "发送邮件"))


