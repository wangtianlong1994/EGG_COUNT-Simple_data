# import wiringpi
import time
from PyQt5.QtCore import QThread, pyqtSignal

GPIO_Intput_Pin = 5   #定义GPIO_Intput_Pin为0脚
INPUT = 0               #定义INPUT为0即输入
PUD_DOWN = 1

# wiringpi.wiringPiSetup()                    #设置GPIO编号为wPi方式
# wiringpi.pinMode(GPIO_Intput_Pin,INPUT)     #设置GPIO_Intput_Pin为INPUT输入模式
# wiringpi.pullUpDnControl(GPIO_Intput_Pin,PUD_DOWN) #she zhi xia la dianzu



class MyThread(QThread): # 建立一个任务线程类
    signals = pyqtSignal(int) #设置触发信号传递的参数数据类型,这里是字符串
    def __init__(self):
        super(MyThread, self).__init__()
        self.det_signal = 0
        self.signal_num = 0

    def run(self): # 在启动线程后任务从这个函数里面开始执行
        while True:
            signal = 0 #wiringpi.digitalRead(GPIO_Intput_Pin)
            if signal and not self.det_signal:
                print(self.signal_num)
                self.det_signal = 1
                if self.signal_num == 0:
                    self.signals.emit(int(self.signal_num))
                    self.signal_num += 1
                    time.sleep(0.001)
                    continue
                elif self.signal_num == 5:
                    self.signal_num = 0
                    time.sleep(0.001)
                    continue
                self.signal_num += 1
            elif signal and self.det_signal:
                pass
            else:
                self.det_signal = 0
            time.sleep(0.001)
